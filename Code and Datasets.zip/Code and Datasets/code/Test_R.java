package ceka.DVLI;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

import DVLIa.DVLIa;
import DVLIdt.DVLIdt;
import DVLIlr.DVLIlr;
import DVLIsvm.DVLIsvm;
import ceka.DTWMV.CekaUtils;
import ceka.DTWMV.DTWMV;
import ceka.DVNC.DVNC;
import ceka.IWMV.IWMV;
import ceka.MNLDP.MNLDP;
import ceka.MVNC.MVNC;
import ceka.TDLI.TDLI;
//import ceka.IWMV.IWMV;
//import ceka.LAWMV.LAWMV;
//import ceka.MNLDP.MNLDP;
import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.utils.PerformanceStatistic;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
public class Test_R {

	private static String dataSetArffDir = "D:\\CEKA\\dataset\\real-world\\";

	private static String[] dataSetArddFix = {"income94L10","leaves6","labelme","music_genre"};

	private static String runDir = "./test/ceka/DVLI/Results/";

	private static int times = 1;

	/** the classifier of calculate the precision */


	@SuppressWarnings("static-access")
	public static void main(String[] args) throws Exception {

		File testDir = new File(runDir);
		if (!testDir.exists()) {
			testDir.mkdirs();
		}

		// write the result to a file
		FileOutputStream f_i = new FileOutputStream(new File(runDir + "resultR_F1.xlsx"));
		FileOutputStream f_c = new FileOutputStream(new File(runDir + "resultR_Acc.xlsx"));
		
		PrintStream result_c = new PrintStream(f_c);

		result_c.format("%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s", "dataset","MV","IWMV","DTWMV","MNLDP","TDLI","MVNC","DVNC","DVLI");
		result_c.println();

	
		double Acc_mv_all_sum = 0.0;
		double Acc_dvli_all_sum = 0.0;
		double Acc_mvnc_all_sum = 0.0;
		double Acc_dvnc_all_sum = 0.0;
		double Acc_mnldp_all_sum = 0.0;
		double Acc_tdli_all_sum = 0.0;
		double Acc_iwmv_all_sum = 0.0;
		double Acc_dtwmv_all_sum = 0.0;
		

		for (String element : dataSetArddFix) {

			String arffxPath = dataSetArffDir + element +"\\"+ element+ ".arff";
			String arffxPathx = dataSetArffDir + element +"\\"+ element+ ".arffx";
			String responsePath=dataSetArffDir + element+"\\"+  element + ".response.txt";
			String goldPath=dataSetArffDir + element +"\\"+ element+ ".gold.txt";
		
			 Dataset dataset;
		        try {
		            dataset = FileLoader.loadFileX(responsePath, goldPath, arffxPathx);
		         
		        } catch (Exception e) {
		            String arffPath;
					dataset = FileLoader.loadFile(responsePath, goldPath, arffxPath);
					
		        }		       

			System.out.println(element);


			double Acc_mv = 0.0;
			double Acc_dvli = 0.0;
			double Acc_mvnc = 0.0;
			double Acc_dvnc = 0.0;
			double Acc_mnldp = 0.0;
			double Acc_tdli = 0.0;
			double Acc_iwmv = 0.0;
			double Acc_dtwmv = 0.0;
		

			for (int counts = 0; counts < times; counts++) {
				
				Dataset datasetMV = CekaUtils.datasetCopy(dataset);
				
				 MajorityVote mv = new MajorityVote();
				datasetMV=mv.doInference(datasetMV);
				PerformanceStatistic reporter = new PerformanceStatistic();
				reporter.stat(datasetMV);
				Acc_mv += reporter.getAccuracy() * 100;


				
				Dataset datasetIWMV = CekaUtils.datasetCopy(dataset);
				IWMV wmv3=new IWMV();
				wmv3.doInference(datasetIWMV);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV);
				Acc_iwmv += reporter.getAccuracy() * 100;
				 System.out.println("IWMV: " );

				//DTWMV
				Dataset datasetDTWMV = CekaUtils.datasetCopy(dataset);
				DTWMV dtwmv = new DTWMV();
				datasetDTWMV=dtwmv.doInference(datasetDTWMV);
				System.out.println("DTWMV: " );
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDTWMV);
				Acc_dtwmv += reporter.getAccuracy() * 100;
					
				Dataset datasetMNLDP = CekaUtils.datasetCopy(dataset);
				MNLDP dtwmv2 = new MNLDP();
				dtwmv2.doInference(datasetMNLDP);
		        System.out.println("MNLDP: " );
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP);
				Acc_mnldp += reporter.getAccuracy() * 100;
				
				//TDLI
				Dataset datasetTDLI = CekaUtils.datasetCopy(dataset);
				TDLI dtwmv11 = new TDLI();
				datasetTDLI=dtwmv11.doInference(datasetTDLI);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetTDLI);
				Acc_tdli += reporter.getAccuracy() * 100;
				 System.out.println("TDLI: " );
				
				Dataset datasetMVNC = CekaUtils.datasetCopy(dataset);
				MajorityVote mv1 = new MajorityVote();
				mv1.doInference(datasetMVNC);
				MVNC dtwmv3 = new MVNC();
				 datasetMVNC=dtwmv3.doInference(datasetMVNC);
		        System.out.println("MVNC: ");
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMVNC);
				Acc_mvnc += reporter.getAccuracy() * 100;


			
				Dataset datasetDVNC = CekaUtils.datasetCopy(dataset);
				DVNC dtwmv22 = new DVNC();
				datasetDVNC=dtwmv22.doInference(datasetDVNC,0.6);
		        System.out.println("DVNC: ");
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDVNC);
				Acc_dvnc += reporter.getAccuracy() * 100;

				

				Dataset datasetDVLI = CekaUtils.datasetCopy(dataset);
				DVLI wmv222 = new DVLI();
				datasetDVLI=wmv222.doInference(datasetDVLI,0.3);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDVLI);
				Acc_dvli += reporter.getAccuracy() * 100;
				 System.out.println("DVLI: ");

				

			}


			Acc_mv_all_sum += Acc_mv / times;
			Acc_dvli_all_sum += Acc_dvli / times;
			Acc_mvnc_all_sum += Acc_mvnc / times;
			Acc_dvnc_all_sum += Acc_dvnc / times;
			Acc_tdli_all_sum += Acc_tdli / times;
			Acc_mnldp_all_sum += Acc_mnldp / times;
			Acc_iwmv_all_sum += Acc_iwmv / times;
			Acc_dtwmv_all_sum += Acc_dtwmv / times;

			
			result_c.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", element,
					Acc_mv / times,  Acc_iwmv/times,


					Acc_dtwmv / times,Acc_mnldp / times,
					Acc_tdli / times,Acc_mvnc / times,
					Acc_dvnc / times,Acc_dvli / times);
			result_c.println();
		}
		
		result_c.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", "Average",
				Acc_mv_all_sum / dataSetArddFix.length,
				Acc_iwmv_all_sum / dataSetArddFix.length,
				Acc_dtwmv_all_sum / dataSetArddFix.length,
				Acc_mnldp_all_sum / dataSetArddFix.length,
				Acc_tdli_all_sum / dataSetArddFix.length,
				Acc_mvnc_all_sum / dataSetArddFix.length,
				Acc_dvnc_all_sum / dataSetArddFix.length,
				Acc_dvli_all_sum / dataSetArddFix.length);
		result_c.close();
	}

}