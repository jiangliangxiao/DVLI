package ceka.DVLI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Random;

import org.apache.log4j.Logger;

import DVLIa.DVLIa;
import ceka.AALI.AALI;
import ceka.DTWMV.CekaUtils;
import ceka.DTWMV.DTWMV;
import ceka.DVNC.DVNC;
import ceka.IWMV.IWMV;
import ceka.MNLDP.MNLDP;
import ceka.MVNC.MVNC;
import ceka.TDLI.TDLI;
import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.MultiNoisyLabelSet;
import ceka.core.Worker;
//import ceka.simulation1.*;
import ceka.simulation.GaussianLabelingStrategy;
import ceka.utils.PerformanceStatistic;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
//import myqpmatlab.MyQP;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;
public class Test_S {

	private static String dataSetArffDir = "D:\\CEKA\\Ceka-v1.0.1\\dataset\\simulation\\";

	private static String[] dataSetArddFix = new File(dataSetArffDir).list();

	private static String runDir = "./test/ceka/DVLI/Results/";

	private static int times = 1;

	private static int MAX_WKR = 5;
	private static Logger log = Logger.getLogger(GaussianLabelingStrategy.class);

//	// 生成符合正态分布的质量值，限制在[min, max]之间

	private static double generateGaussianQuality(double mean, double stddev, double min, double max, Random rand) {
        double quality;
        do {
            quality = mean + stddev * rand.nextGaussian(); 
        } while (quality <= min || quality >= max); 
        return quality;
    }

	private static void AddWorker(Dataset dataset1, int num_workers) {
        int num_examples = dataset1.getExampleSize();
        int num_classes = dataset1.numClasses();
        double[] workerP = new double[num_workers];
        double[] workerQ = new double[num_workers];
       
        for(int w=0;w<num_workers;w++) {
       
           workerP[w] = 1;
           workerQ[w] = Math.random() * 0.4 + 0.5;
            System.out.println(workerQ[w]+",");
        }
     
        for(int w=0;w<num_workers;w++) {
            Worker worker1 = new Worker(String.valueOf(w));
            dataset1.addWorker(worker1);
        }

        for( int i=0;i<num_examples;i++) {
            
            Example example1 = dataset1.getExampleByIndex(i);
            for(int w=0;w<num_workers;w++) {
                if(Math.random()<workerP[w]) {
                    
                    Worker worker1 = dataset1.getWorkerByIndex(w);
                    int true_label = example1.getTrueLabel().getValue();
                    
                    if(Math.random()>workerQ[w]) {
                        int false_label = true_label;
                        while(false_label == true_label) {
                            Random random = new Random();
                            false_label = random.nextInt(num_classes);
                        }
                        true_label = false_label;
                    }
                    Label label1 = new Label(null,String.valueOf(true_label),example1.getId(),worker1.getId());
                    
                    example1.addNoisyLabel(label1);
                    worker1.addNoisyLabel(label1);
                    
                }
            }
            MultiNoisyLabelSet mnls = example1.getMultipleNoisyLabelSet(0);
            if(mnls.getLabelSetSize()==0) {
				i--;
			}
        }
    }

	public static void main(String[] args) throws Exception {

		File testDir = new File(runDir);
		if (!testDir.exists()) {
			testDir.mkdirs();
		}

		
		FileOutputStream f_c = new FileOutputStream(new File(runDir + "result_Acc.xlsx"));
	
		PrintStream result_c = new PrintStream(f_c);

	
		result_c.format("%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s", "dataset","MV","IWMV","DTWMV","MNLDP","TDLI","MVNC","DVNC","DVLI");
		result_c.println();


		double Acc_mv_all_sum = 0.0;
		double Acc_dvli_all_sum = 0.0;
		double Acc_mvnc_all_sum = 0.0;
		double Acc_dvnc_all_sum = 0.0;
		double Acc_mnldp_all_sum = 0.0;
		double Acc_tdli_all_sum = 0.0;
		double Acc_iwmv_all_sum = 0.0;
		double Acc_dtwmv_all_sum = 0.0;



		for (String element : dataSetArddFix) {

			String datasetArffPath = dataSetArffDir + element;
			Dataset dataset = FileLoader.loadFile(datasetArffPath);
		
			System.out.println(element);

			ReplaceMissingValues m_Missing = new ReplaceMissingValues();
			m_Missing.setInputFormat(dataset);
			Instances instances = Filter.useFilter(dataset, m_Missing);
			dataset = CekaUtils.instancesToDataset(instances,dataset);

			AddWorker(dataset,MAX_WKR);



			double Acc_mv = 0.0;
			double Acc_dvli = 0.0;
			double Acc_mvnc = 0.0;
			double Acc_dvnc = 0.0;
			double Acc_mnldp = 0.0;
			double Acc_tdli = 0.0;
			double Acc_iwmv = 0.0;
			double Acc_dtwmv = 0.0;

			for (int counts = 0; counts < times; counts++) {

				Dataset datasetMV = CekaUtils.datasetCopy(dataset);
				
				 MajorityVote mv = new MajorityVote();
				datasetMV=mv.doInference(datasetMV);
				PerformanceStatistic reporter = new PerformanceStatistic();
				reporter.stat(datasetMV);
				Acc_mv += reporter.getAccuracy() * 100;


				
				Dataset datasetIWMV = CekaUtils.datasetCopy(dataset);
				IWMV wmv3=new IWMV();
				wmv3.doInference(datasetIWMV);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV);
				Acc_iwmv += reporter.getAccuracy() * 100;
				 System.out.println("IWMV: " );


				Dataset datasetMVNC = CekaUtils.datasetCopy(dataset);
				MajorityVote mv1 = new MajorityVote();
				mv1.doInference(datasetMVNC);
				MVNC dtwmv3 = new MVNC();
				 datasetMVNC=dtwmv3.doInference(datasetMVNC);
		        System.out.println("MVNC: ");
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMVNC);
				Acc_mvnc += reporter.getAccuracy() * 100;


			
				Dataset datasetDVNC = CekaUtils.datasetCopy(dataset);
				DVNC dtwmv22 = new DVNC();
				datasetDVNC=dtwmv22.doInference(datasetDVNC,0.6);
		        System.out.println("DVNC: ");
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDVNC);
				Acc_dvnc += reporter.getAccuracy() * 100;

				
				Dataset datasetMNLDP = CekaUtils.datasetCopy(dataset);
				MNLDP dtwmv2 = new MNLDP();
				dtwmv2.doInference(datasetMNLDP);
		        System.out.println("MNLDP: " );
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP);
				Acc_mnldp += reporter.getAccuracy() * 100;



				//TDLI
				Dataset datasetTDLI = CekaUtils.datasetCopy(dataset);
				TDLI dtwmv11 = new TDLI();
				datasetTDLI=dtwmv11.doInference(datasetTDLI);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetTDLI);
				Acc_tdli += reporter.getAccuracy() * 100;
				 System.out.println("TDLI: " );

				//DTWMV
				Dataset datasetDTWMV = CekaUtils.datasetCopy(dataset);
				DTWMV dtwmv = new DTWMV();
				datasetDTWMV=dtwmv.doInference(datasetDTWMV);
				System.out.println("DTWMV: " );
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDTWMV);
				Acc_dtwmv += reporter.getAccuracy() * 100;

				
				Dataset datasetDVLI = CekaUtils.datasetCopy(dataset);
				DVLI wmv222 = new DVLI();
				datasetDVLI=wmv222.doInference(datasetDVLI,0.3);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDVLI);
				Acc_dvli += reporter.getAccuracy() * 100;
				 System.out.println("DVLI: ");


			}

		
			Acc_mv_all_sum += Acc_mv / times;
			Acc_dvli_all_sum += Acc_dvli / times;
			Acc_mvnc_all_sum += Acc_mvnc / times;
			Acc_dvnc_all_sum += Acc_dvnc / times;
			Acc_tdli_all_sum += Acc_tdli / times;
			Acc_mnldp_all_sum += Acc_mnldp / times;
			Acc_iwmv_all_sum += Acc_iwmv / times;
			Acc_dtwmv_all_sum += Acc_dtwmv / times;

			
			result_c.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", element,
					Acc_mv / times,  Acc_iwmv/times,


					Acc_dtwmv / times,Acc_mnldp / times,
					Acc_tdli / times,Acc_mvnc / times,
					Acc_dvnc / times,Acc_dvli / times);
			result_c.println();
		}
		
		result_c.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", "Average",
				Acc_mv_all_sum / dataSetArddFix.length,
				Acc_iwmv_all_sum / dataSetArddFix.length,
				Acc_dtwmv_all_sum / dataSetArddFix.length,
				Acc_mnldp_all_sum / dataSetArddFix.length,
				Acc_tdli_all_sum / dataSetArddFix.length,
				Acc_mvnc_all_sum / dataSetArddFix.length,
				Acc_dvnc_all_sum / dataSetArddFix.length,
				Acc_dvli_all_sum / dataSetArddFix.length);
		result_c.close();
	}

}