package ceka.DVLI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ceka.consensus.MajorityVote;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.MultiNoisyLabelSet;
import ceka.core.Worker;
import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Utils;

public class DVLI {

    public static final String NAME = "DVLI";
    public static Map<String, Integer> mapWorker = new HashMap<>(); 

    public Dataset doInference(Dataset dataset, double gamma) throws Exception {



        int numAttributes = dataset.numAttributes(); 
        int numWorkers = dataset.getWorkerSize(); 
        int numClasses = dataset.numClasses(); 
        int numExample = dataset.numInstances(); 

        MajorityVote mv = new MajorityVote();
        mv.doInference(dataset);

        Classifier classifier1=new NaiveBayes();
        for (int i = 0; i < numExample; i++) {

            Example e = dataset.getExampleByIndex(i);
            e.setWeight(1.0);
        }
		   Dataset dataset2=copyDataset(dataset);

       
        for (int i = 0; i < numAttributes - 1; i++) {
            dataset.deleteAttributeAt(0);
        }

        for (int i = 0; i < numWorkers; i++) {

            Worker worker = dataset.getWorkerByIndex(i);

            mapWorker.put(worker.getId(), i);

            FastVector attributeValues = new FastVector();
            for (int j = 0; j < numClasses; j++) {
                attributeValues.addElement(j + "");
            }
            attributeValues.addElement(numClasses + "");

            Attribute att = new Attribute(worker.getId(), attributeValues);
            dataset.insertAttributeAt(att, dataset.numAttributes() - 1);
        }


        for (int i = 0; i < numExample; i++) {

            Example e = dataset.getExampleByIndex(i);

           
            for (int j = 0; j < dataset.numAttributes() - 1; j++) {
                e.setValue(dataset.attribute(j), numClasses + "");
            }
            ArrayList<String> workerIdList = e.getWorkerIdList();
            for (String element : workerIdList) {
                e.setValue(dataset.attribute(element),
                        (e.getNoisyLabelByWorkerId(element).getValue()) + "");
            }

            double[] classCounts = new double[numClasses];
			MultiNoisyLabelSet mnls = e.getMultipleNoisyLabelSet(0);
			for(int j = 0; j < mnls.getLabelSetSize(); j++){
				classCounts[mnls.getLabel(j).getValue()] += 1.0;
			}

            e.setWeight(1.0);
        }
        for (int i = 0; i < dataset2.getExampleSize(); i++) {
		    Example e = dataset2.getExampleByIndex(i);
		    e.setWeight(1.0);
		  
	   }

        int num1=1;
        double[] insweight=new double[numExample];
        double[] workerweight=new double[numWorkers];

     
        while(num1!=0) {
      
        	num1=0;
        	workerweight = computeWorkerWeights1(dataset);
  		   classifier1.buildClassifier(dataset2);


        for (int i = 0; i < dataset.numInstances(); i++) {
            
            double[] classCounts = new double[numClasses];
            Example e = dataset.getExampleByIndex(i);
            double initialLabel = e.getIntegratedLabel().getValue();
            Example e2 = dataset2.getExampleByIndex(i);
            MultiNoisyLabelSet mnls = e.getMultipleNoisyLabelSet(0);
            
            for (int j = 0; j < mnls.getLabelSetSize(); j++) {
                String workerId = mnls.getLabel(j).getWorkerId();  
                int workerIndex = mapWorker.get(workerId);  
                int labelValue = mnls.getLabel(j).getValue();
            	 classCounts[labelValue] += workerweight[workerIndex];

           }

            ArrayList<Integer> maxList = new ArrayList<>();
            int maxIndex = Utils.maxIndex(classCounts);
            maxList.add(maxIndex);

            for (int j = 0; j < numClasses; j++) {
                if (classCounts[j] == classCounts[maxIndex]) {
                    maxList.add(j);
                }
            }

            int selectedClass = 0;
            if (maxList.size() > 1) {
               double r = Math.random();  
                double grain = 1.0 / maxList.size(); 
                selectedClass = maxList.get((int) (r / grain)); 
            } else {
                selectedClass = maxList.get(0); 
            }


            Label label = new Label(null, String.valueOf(selectedClass), e.getId(), NAME);

            Label label1 = new Label(null, String.valueOf((int) classifier1.classifyInstance(e2)), e2.getId(), NAME);

              if(label.getValue()==label1.getValue()&&label.getValue()!= initialLabel) {
            	  num1++;
            	e.setIntegratedLabel(label);
                e2.setIntegratedLabel(label1);


            }

        }

        dataset.assignIntegeratedLabel2WekaInstanceClassValue();
        dataset2.assignIntegeratedLabel2WekaInstanceClassValue();
        insweight=computeLabelWeights(dataset,workerweight);
        for (int i = 0; i < dataset.numInstances(); i++) {
           
            Example e = dataset.getExampleByIndex(i);
            Example e2 = dataset2.getExampleByIndex(i);
            e.setWeight(insweight[i]);
            e2.setWeight(insweight[i]);
            }


     }

        
        for (int i = 0; i < dataset.numInstances(); i++) {
            
            Example e = dataset.getExampleByIndex(i);
            Example e2 = dataset2.getExampleByIndex(i);
            e.setWeight(insweight[i]);
            e2.setWeight(insweight[i]);
            }
        classifier1.buildClassifier(dataset2);

		   for (int i = 0; i < dataset.numInstances(); i++) {
	        
	            double[] classCounts = new double[numClasses];
	           
	            Example e = dataset.getExampleByIndex(i);
	            Example e2 = dataset2.getExampleByIndex(i);
	       
	            MultiNoisyLabelSet mnls = e.getMultipleNoisyLabelSet(0);
	            double sumweight=0.0;
	         
	            for (int j = 0; j < mnls.getLabelSetSize(); j++) {
	                String workerId = mnls.getLabel(j).getWorkerId();  
	                int workerIndex = mapWorker.get(workerId);  
	                int labelValue = mnls.getLabel(j).getValue(); 
	                double adjustedWeight=0.0;
	                adjustedWeight =workerweight[workerIndex];
	                sumweight+=adjustedWeight;
	            	 classCounts[labelValue] += adjustedWeight;

	           }
	            for (int k = 0; k < numClasses; k++) {
	            	classCounts[k]/=sumweight;
	            	classCounts[k]*=(1-gamma);//第二视图
	            }


	            for (int k = 0; k < numClasses; k++) {

	            	classCounts[k]+=(gamma)*classifier1.distributionForInstance(e2)[k];//第一视图
	            }
	          
	            ArrayList<Integer> maxList = new ArrayList<>();
	            int maxIndex = Utils.maxIndex(classCounts);  
	            maxList.add(maxIndex);

	            for (int j = 0; j < numClasses; j++) {
	                if (classCounts[j] == classCounts[maxIndex]) {
	                    maxList.add(j);
	                }
	            }

	            int selectedClass = 0;
	            if (maxList.size() > 1) {
	            	
	                double r = Math.random();  
	                double grain = 1.0 / maxList.size(); 
	                selectedClass = maxList.get((int) (r / grain)); 
	            } else {
	                selectedClass = maxList.get(0);
	            }

	            Label label = new Label(null, String.valueOf(selectedClass), e.getId(), NAME);

	            	e.setIntegratedLabel(label);

	        }
		
		   dataset.assignIntegeratedLabel2WekaInstanceClassValue();
		   
		   return dataset;
     }





      public static double[] computeWorkerWeights1(Dataset dataset) {
    	  int numWorkers=dataset.getWorkerSize();
          double[] workerWeights = new double[numWorkers];
          double[] correctCounts = new double[numWorkers];
          double[] totalCounts = new double[numWorkers];

          for (Example e : dataset.getExamples()) {
        	 
              int integratedLabel = e.getIntegratedLabel().getValue(); //
              MultiNoisyLabelSet mnls = e.getMultipleNoisyLabelSet(0);

              for (int i = 0; i < mnls.getLabelSetSize(); i++) {

                  String workerId = mnls.getLabel(i).getWorkerId();
                  int workerIndex = mapWorker.get(workerId);
                  int labelValue = mnls.getLabel(i).getValue();

                  if (labelValue == integratedLabel) {
                  	 correctCounts[workerIndex]+=e.weight();//嵌入实例权值

                  }
                  totalCounts[workerIndex]+=e.weight();
              }
            
          }

          for (int i = 0; i < numWorkers; i++) {
              workerWeights[i] = totalCounts[i] == 0 ? 0 : correctCounts[i] /totalCounts[i];
             
          }

          return workerWeights;
      }

      public static double[] computeLabelWeights(Dataset data, double[] Workerweights) {
      	int numInstances = data.numInstances();
      	int numClasses = data.numClasses();
      	double[] trustScores = new double[numInstances];
      	
          for (int i = 0; i < numInstances; i++) {
        	  double[] classCounts = new double[numClasses];
          	Example e = data.getExampleByIndex(i);
          	MultiNoisyLabelSet mnls = e.getMultipleNoisyLabelSet(0);
          	int integratedLabel = e.getIntegratedLabel().getValue();
          	for(int j = 0; j < mnls.getLabelSetSize(); j++){
          		 String workerId = mnls.getLabel(j).getWorkerId();
                 int workerIndex = mapWorker.get(workerId);
      			classCounts[mnls.getLabel(j).getValue()] +=  Workerweights[workerIndex];//嵌入工人权值
      		}

              trustScores[i] = classCounts[integratedLabel]/Utils.sum(classCounts);
             
          }

          return trustScores;
      }

      public static Dataset copyDataset(Dataset dataset) {
  		Dataset copyDataset = new Dataset(dataset, 0);
  		for (int k = 0; k < dataset.getExampleSize(); k++) {
  			Example example = dataset.getExampleByIndex(k);
  			copyDataset.addExample(example);
  		}
  		for (int k = 0; k < dataset.getCategorySize(); k++) {
  			Category category = dataset.getCategory(k);
  			copyDataset.addCategory(category);
  		}
  		for (int k = 0; k < dataset.getWorkerSize(); k++) {
  			Worker worker = dataset.getWorkerByIndex(k);
  			copyDataset.addWorker(worker);
  		}
  		return copyDataset;
  	}
}
